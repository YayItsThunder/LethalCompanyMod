Replace delivery music with chipichipchapachapa music, created by YayItsThunder and Bing2Na, all rights reserved.


**Make sure to change the config in BepInEx.cfg. In particular, set the following parameter to true: **


[Chainloader] HideManagerGameObject = true.


**CustomSounds will NOT work if you don't set this paremeter.**