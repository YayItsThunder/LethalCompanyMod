Updated Ver 1.0.2, volume adjusted.

Uploaded Ver 1.0.0, first upload.