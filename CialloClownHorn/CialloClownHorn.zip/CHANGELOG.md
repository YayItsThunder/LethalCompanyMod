Update to Ver 1.2.2, changed description.


**DO NOT USE OTHER VERSION, MAY CAUSE MOD OVERRIDE**