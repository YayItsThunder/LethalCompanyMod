Updated Ver 1.0.1, changed descrption.

Upload Ver 1.0.0, random AUGHHH
